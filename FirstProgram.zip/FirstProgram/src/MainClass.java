
public class MainClass {
	
	
	public static int Add(int num1,int num2) {
		return num1 + num2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1 = Integer.parseInt(args[0]);
		int n2 = Integer.parseInt(args[1]);
		int result = MainClass.Add(n1, n2);
		System.out.printf("Addition Result is : %d%n",result);

	System.out.println("Kobe bryant\n");    //syso->ctrl+Spbr
	}   

}
