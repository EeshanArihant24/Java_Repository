package Banking;

public class ComoundInterestCalculator {

	public double getCompoundInterest(double p,double r, int n) {
		
		// a = p *(1+r/100)
		double amount = p * (Math.pow((1+r/100),n));
		double interest = amount - p;
		return interest;
	}
}
