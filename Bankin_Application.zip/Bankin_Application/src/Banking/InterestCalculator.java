package Banking;

public class InterestCalculator {

	//static getsimpleInterest(....)
	// static 
	
	public static double getSimpleInterest(double amount, double rate,int period) {
		return amount * rate * period / 100;
	}
}

