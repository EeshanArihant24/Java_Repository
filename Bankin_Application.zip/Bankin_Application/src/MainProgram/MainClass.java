package MainProgram;

import Banking.InterestCalculator;
import Banking.ComoundInterestCalculator;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//java MainClass 10000 10 3
		//args[0] -> 10000
		//args[1] -> 10
		//args[2] -> 3
		double amount = Double.parseDouble(args[0]);

		double rate = Double.parseDouble(args[1]);

		int period = Integer.parseInt(args[2]);
		
		// Call InterestCalaculator.getSimpleInterest(a,r,p)
		double interest = InterestCalculator.getSimpleInterest(amount,rate,period);
	    System.out.printf("Calculated Simple Interest is %f%n",interest);
	    ComoundInterestCalculator ci = new ComoundInterestCalculator();
	    
	    interest = ci.getCompoundInterest(amount, rate, period);
	    System.out.printf("Calculated Compound Interest is %f%n",interest);
		
        System.out.println("Your Welcome");
	}

}
