package MET;

public class SalesPerson extends Employee{
	protected double sales;

	public SalesPerson() {
		super();  // super here refers to Employee ctor
		// TODO Auto-generated constructor stub
	}

	public SalesPerson(float rate, int hours, double ss) {
		super(rate, hours);    // super here refers to Employee ctor
		// TODO Auto-generated constructor stub
	}

	public double getSales() {
		return sales;
	}

	public void setSales(double sales) {
		this.sales = sales;
	}
	
	public double income() {
		double i = super.income();
		i = i + 0.25 * sales;
		return i;
	}

}
