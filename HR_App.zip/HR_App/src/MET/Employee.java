package MET;

public class Employee {
protected int id;
protected float rate;
protected int hours;
protected static int count = 0;
public Employee(){
	id = ++count;
System.out.println("Employee Instance created");
}

public Employee(float rate, int hours) {
	id = ++count;
	this.rate = rate;
	this.hours = hours;
	System.out.println("\nEmployee  Instance Created");
}

public float getRate() {
	return rate;
}

public void setRate(float rate) {
	this.rate = rate;
}

public int getId() {
	return id;
}

public int getHours() {
	return hours;
}

public static int getCount() {
	return count;
}
public double income() {
	return (hours * rate) * 12 * 1.2;
}
}
