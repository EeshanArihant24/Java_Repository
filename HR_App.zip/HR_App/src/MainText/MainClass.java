package MainText;

import MET.Employee;
import MET.SalesPerson; 
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee(200,200);
		System.out.printf("Id = %d ,Income is %f",e.getId(),e.income());
		SalesPerson sp = new SalesPerson(200,200,50000);
		System.out.printf("Id = %d ,Income is %f",sp.getId(),sp.income());
		
		System.out.println("\nWelcome"); 
	}
}
