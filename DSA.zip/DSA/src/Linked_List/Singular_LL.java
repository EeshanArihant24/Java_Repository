package Linked_List;

public class Singular_LL {
	Node head;
	class Node{
		String data;
		Node next;
		
		Node(String data){
			this.data= data;
			this.next=null;
		}
	}
	
	public void addFirst(String data) {
		Node newNode = new Node(data);
		if(head == null) {
			head = newNode;
			return;
		}
		newNode.next = head;
		head = newNode;
	}
	
	public void addLast(String data) {
		Node newNode = new Node(data);
		if(head == null) {
			head = newNode;
			return;
		}
		
		Node currNode = head;
		while(currNode.next != null) {
			currNode = currNode.next;
		}
		currNode.next = newNode;
	}
	
	public void printList() {
		if(head == null) {
			System.out.println("List is Empty");
		}
		Node currNode = head;
		while(currNode != null) {
			System.out.print(currNode.data +" -> ");
			currNode = currNode.next;
		}
		System.out.println("Null");
		
		}
	public class Main_LL {
		public static void main(String args[]) {
			Singular_LL list = new Singular_LL();
			list.addFirst("kobe");
			list.addFirst("is");
			list.printList();
			
			list.addLast("24");
			list.printList();
			
			list.addFirst("This");
			list.printList();
			

	}
}
}
