package Linked_List;

public class Main_LL {
	public static void main(String args[]) {
		Main_LL list = new Main_LL();
		list.addFirst("kobe");
		list.addFirst("is");
		list.printList();
		
		list.addLast("24");
		list.printList();
		
		list.addFirst("This");
		list.printList();
		

}
