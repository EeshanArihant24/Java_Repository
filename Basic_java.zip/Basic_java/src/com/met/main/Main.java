package com.met.main;

import com.met.model.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//System.out.println("kobe");
Student s1 = new Student(20,"james", 99);   // parameterized cotr

System.out.println("ID: " + s1.getId());
System.out.println("Name: " + s1.getName());
System.out.println("Marks: " + s1.getMarks());


s1.setName("Curry");
s1.setMarks(80);
System.out.println("After Update");
System.out.println("Name: " + s1.getName());
System.out.println("Marks: " + s1.getMarks());


System.out.println("Command Line Argument " + args[2]);
	}

}
