package Met;

public class Main {

	public static void main(String[] args) {
		System.out.println("Welcome Student");
		//Student stdt = new Student();
		Student stdt1 = new Student("KYC", 88);
		//System.out.print("stdt\n");
		//System.out.printf("Status of above stdt : %b%n",stdt.isPassed());
		System.out.println("==========================");
		System.out.print("stdt1\n");
		System.out.printf("Status of stdt1 : %b%n",stdt1.isPassed());
		System.out.printf("Name of stdt1 : %s%n ",stdt1.name);
		System.out.printf("Roll No of stdt1 : %s%n ",stdt1.rollno);
		System.out.println("==========================");
		Student stdt2 = new Student("ABC", 38);
		System.out.print("stdt2\n");
		System.out.printf("Status of stdt2 : %b%n",stdt2.isPassed());
		System.out.printf("Name of stdt2 : %s%n ",stdt2.name);
		System.out.printf("Roll No of stdt2 : %s%n ",stdt2.rollno);
		System.out.println("==========================");
		Student stdt3 = new Student("PQY", 81);
		System.out.print("stdt3\n");
		System.out.printf("Status of stdt3 : %b%n",stdt3.isPassed());
		System.out.printf("Name of stdt3 : %s%n ",stdt3.name);
		System.out.printf("Roll No of stdt3 : %s%n ",stdt3.rollno);
		System.out.println("==========================");
		
		

	}

}
