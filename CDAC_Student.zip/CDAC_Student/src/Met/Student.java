package Met;

public class Student {
	protected int rollno;
	protected String name;
	protected float marks;
	public static int count = 0;
	
	public Student(String name, float marks) {
		rollno = ++count;
		this.name = name;
		this.marks = marks;
		System.out.println("Student Instance Created");
	}
	//public Student() {
		//this("ABC",30);
	//}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getMarks() {
		return marks;
	}
	public void setMarks(float marks) {
		this.marks = marks;
	}
	public int getRollno() {
		return rollno;
	}
	public static int getCount() {
		return count;
	}
    public  boolean isPassed() {
    	return marks >= 40;
    }
    public void Display() {
    	System.out.println("Roll No \n");

    	System.out.println("Name \n");

    	System.out.println("Marks \n");
    }
    public String toString() {
    	return String.format("RollNo = %d Name %c with marks %f%n", rollno, name, marks);
    }
}
